package com.lcwd.mvc.SpringMvcProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
