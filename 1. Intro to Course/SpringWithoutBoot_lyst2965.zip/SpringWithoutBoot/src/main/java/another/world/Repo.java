package another.world;

public class Repo {
    public void getUser(){
        System.out.println("Getting all user");
    }
}
