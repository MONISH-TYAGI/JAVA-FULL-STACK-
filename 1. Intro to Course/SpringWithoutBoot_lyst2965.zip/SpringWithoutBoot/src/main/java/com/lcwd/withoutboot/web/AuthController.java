package com.lcwd.withoutboot.web;

public class AuthController {
    public void login() {
        System.out.println("One user is logged in");
    }
}
