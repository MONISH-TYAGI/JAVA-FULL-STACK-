package com.lcwd.withoutboot.beans;

public class CartService {
    public  void createCart(){
        System.out.println("one cart is created");
    }
}
