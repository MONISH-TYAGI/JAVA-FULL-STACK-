package com.lcwd.withoutboot.web;


public class HomeController {
    public void homePage(){
        System.out.println("home page is called");
    }
}
