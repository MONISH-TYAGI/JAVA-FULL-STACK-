package com.lcwd.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCoreConceptsApplicationTests {

	@Test
	void contextLoads() {
	}

}
