package test;

import org.springframework.stereotype.Component;

@Component
public class Test {
    public void testing(){
        System.out.println("this is testing bean");
    }
}
