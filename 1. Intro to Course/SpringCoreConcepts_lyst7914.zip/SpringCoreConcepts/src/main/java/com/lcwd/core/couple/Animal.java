package com.lcwd.core.couple;

public interface Animal {
    void play();
}
