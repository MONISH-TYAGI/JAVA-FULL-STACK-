class ForExample
{
	public static void main(String[] args) {
		
			// start---1
			// termination condition-- <=20
		// 	// steps: normal incr by 1
		// for(int i=1; i<=20 ; i++ )
		// {

		// 	System.out.println("subscribe to channel "+i);
		// }

// start : 20
// termination condition: >=1
// steps: dec by 1
		// for(int i=20;i>=1;i--)
		// {
		// 	System.out.println("value of i "+i);
		// }

		// for(int i=1;i<=20;i=i+2)
		// {
		// 	System.out.println("value of i is "+i);
		// }

		


	}
}