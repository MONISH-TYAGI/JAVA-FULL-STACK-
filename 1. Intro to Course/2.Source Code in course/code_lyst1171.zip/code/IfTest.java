class IfTest
{
	public static void main(String[] args) {
		

		if("Test"==null)
		{
			System.out.println("If Block");
		}else
		{
			System.out.println("Else Block");
		}

	}
}