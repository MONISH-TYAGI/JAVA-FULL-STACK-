public class JalebiDemo {
    public static void main(String[] args) {

        Jalebi j1 = new Jalebi(500, "Green Jalebi");

        // j1.price = 500;
        // j1.name = "Green Jalebi";

        // j1.showPrice();

        Jalebi j2 = new Jalebi(600, "Red Jalebi");

        // j2.price = 600;
        // j2.name = "Red Jalebi";

        // j2.showPrice();

        j1.displayAll();
        j2.displayAll();

    }
}
