public class Sohanlal extends Mohanlal {
    public C whatsYourName() {
        System.out.println("my name is sohanlal");
        return new C();
    }
}
