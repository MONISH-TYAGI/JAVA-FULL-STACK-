public class OverridingExample {
    public static void main(String[] args) {
        // Mohanlal mohanlal = new Mohanlal();
        // mohanlal.whatsYourName();
        Sohanlal sohanlal = new Sohanlal();
        sohanlal.whatsYourName();
    }
}
