public class Kenra extends Bank {

    public int getRateOfInterest() {
        System.out.println("Kenra Interest: " + 50);
        return 50;
    }

}
