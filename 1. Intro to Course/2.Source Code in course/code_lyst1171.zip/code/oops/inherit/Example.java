interface A extends B, C, D {

}

interface B {

}

interface C {

}

interface D {

}