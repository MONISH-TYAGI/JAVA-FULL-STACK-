public class Bank {

    // bank ke pass ye method
    public int getRateOfInterest() {
        System.out.println("This is bank rate of interest");
        System.out.println("Default rate of interest " + 5);
        return 5;
    }

}
