public class Mohanlal {

    protected A whatsYourName() {
        System.out.println("My name is mohanlal");
        return new A();
    }
}
