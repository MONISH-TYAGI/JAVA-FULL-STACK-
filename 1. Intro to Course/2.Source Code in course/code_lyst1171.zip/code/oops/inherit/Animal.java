class Animal {
    String name = "Animal 12";
    int x = 40;

    public void eat() {
        System.out.println("Animal is eating");
    }

}