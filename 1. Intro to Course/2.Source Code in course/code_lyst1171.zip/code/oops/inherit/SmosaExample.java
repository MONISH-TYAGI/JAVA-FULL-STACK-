public class SmosaExample {
    public static void main(String[] args) {

        Samosa samosa = new Samosa();
        // samosa.age = 40;
        // System.out.println(samosa.age);
        samosa.setAge(-20);
        samosa.showAgeOfSamosa();

    }
}
