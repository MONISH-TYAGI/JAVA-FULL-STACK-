public class CacDemo {
    public static void main(String[] args) {

        Calc calc = new Calc();
        calc.sum(12, 34);
        calc.sum(12, 12, 12);

    }
}
