public class Calc {

    // overloading kya hota hai
    public void sum(int a, int b) {
        System.out.println("adding two numbers ");
        System.out.println(a + b);
    }

    public void sum(int a, int b, int c) {
        System.out.println("adding three number");
        System.out.println(a + b + c);
    }

    public void sum(int a, int b, int c, int d) {
        System.out.println("adding four number");
        System.out.println(a + b + c + d);

    }

}
