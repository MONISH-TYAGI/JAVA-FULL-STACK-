public class Union extends Bank {

    public int getRateOfInterest() {
        System.out.println("Union Bank Rate of Interest : " + 15);
        return 15;
    }
}
