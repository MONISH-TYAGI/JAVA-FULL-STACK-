public class SuperDemo {
    public static void main(String[] args) {
        Child child = new Child(
                "John ",
                "America",
                "mohanlal",
                "ranipur"

        );
        child.displayAll();
    }
}
