public class Demo {
    public static void main(String[] args) {
        Dog dog1 = new Dog();

        dog1.eat();
        System.out.println(dog1.x);
        System.out.println(dog1.name);

        dog1.drink();
        System.out.println(dog1.y);

    }
}
