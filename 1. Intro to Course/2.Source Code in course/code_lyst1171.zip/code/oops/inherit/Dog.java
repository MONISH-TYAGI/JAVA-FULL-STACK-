public class Dog extends Animal {
    int y = 4444;

    public void drink() {
        System.out.println("Dog is drinking water");
    }
}
