class Pen {
    // class body
    // properties/variables[instance]/data members
    String color;
    double price;
    String model;
    // ......

    // behaviors/methods/member methods
    public void write() {
        System.out.println(model + " is writing in " + color + " Color");
    }

    // .....
}
