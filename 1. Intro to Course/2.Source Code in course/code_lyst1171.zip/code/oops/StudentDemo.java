public class StudentDemo {
    public static void main(String[] args) {
        System.out.println("student demo main method");
        new Student();
    }
}
