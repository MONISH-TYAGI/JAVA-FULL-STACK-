class MyClass implements MyInter {
    public void m1() {
        System.out.println("m1 of MyClass");
    }

    public void m2() {
        System.out.println(
                "m2 of MyClass");
    }
}