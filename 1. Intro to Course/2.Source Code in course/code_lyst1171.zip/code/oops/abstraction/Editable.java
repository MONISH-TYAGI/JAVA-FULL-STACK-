interface Editable {

}
