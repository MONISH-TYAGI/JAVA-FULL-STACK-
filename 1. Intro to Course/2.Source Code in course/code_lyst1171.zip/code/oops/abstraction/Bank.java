interface Bank {

    public abstract int getInterest();

    void displayBalance(int accountNo);

}