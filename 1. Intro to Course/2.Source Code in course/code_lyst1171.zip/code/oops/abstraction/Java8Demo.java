public class Java8Demo {
    public static void main(String[] args) {
        Samosa samosa = new TandooriSmosa();
        samosa.createSamosa();
        samosa.showColor();

    }
}
