public class TandooriSmosa implements Samosa {

    public void createSamosa() {
        System.out.println("Creating tandoori Samosa");
    }

    public void showColor() {
        System.out.println("color is green");
    }

}
