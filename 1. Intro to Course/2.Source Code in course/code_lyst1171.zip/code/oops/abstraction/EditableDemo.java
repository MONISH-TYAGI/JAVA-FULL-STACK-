public class EditableDemo implements Editable {

}
