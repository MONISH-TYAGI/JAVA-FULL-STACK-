public class MyInterDemo {
    public static void main(String[] args) {
        System.out.println(MyInter.a);
        MyClass myClass = new MyClass();
        myClass.m1();
        myClass.m2();
        // MyInter.a=52;
    }
}
