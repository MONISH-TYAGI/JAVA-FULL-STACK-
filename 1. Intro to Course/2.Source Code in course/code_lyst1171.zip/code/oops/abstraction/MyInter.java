interface MyInter {
    // variable--> public static final
    int a = 50;

    // public abstact by default add kar diya gaya hai
    void m1();

    void m2();

}