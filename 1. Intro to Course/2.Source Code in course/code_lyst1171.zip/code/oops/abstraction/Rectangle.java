public class Rectangle extends Shape {

    public Rectangle(int length, int breadth) {
        super(length, breadth);
    }

    public void calculatePerimeter() {
        System.out.println("calulating perimter of rectangle");
    }
}
