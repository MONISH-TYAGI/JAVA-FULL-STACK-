public class Drinker {

    public void drink(Pepsi p) {
        System.out.println("drinker is drinking " + p);

    }

}
