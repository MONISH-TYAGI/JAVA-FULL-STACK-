public class Pnb extends Bank {

    public void showBalance() {
        System.out.println("Png is showing balance");
    }

}
