class FinalExample {
    public static void main(String[] args) {

        final int a = 50;
        System.out.println(a);
        // a = 60;
        System.out.println(a);

        final double marks;
        marks = 60.5;
        System.out.println(marks);

    }
}