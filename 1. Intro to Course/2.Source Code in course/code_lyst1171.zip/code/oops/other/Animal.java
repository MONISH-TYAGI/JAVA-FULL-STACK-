public final class Animal {

}
