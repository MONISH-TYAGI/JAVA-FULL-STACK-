public class Bank {
    final public void showRate() {
        System.out.println("Showing bank rate");
    }

    public void showBalance() {
        System.out.println("showing bank balance");
    }
}
