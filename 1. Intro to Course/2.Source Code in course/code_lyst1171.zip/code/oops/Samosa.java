public class Samosa {

    // properties/variables/data members
    // instance variables/non-static variables
    int price;
    String model;
    String color;
    String shape;

    // behaviors/member methods
    // non-static methods/instance methods

    public void showColor() 
    {

        System.out.println("Color is " + color);
    }

    public int getPrice() {
        System.out.println("Price is : " + price);
        return price;
    }

}
