class Student
{
	String name;
	long phone;
	String address;
	String college;

}