class Demo
{

	public static void main(String args[])
	{
		System.out.println("Hello World !!");
		int a=45;
		int b=12;
		int c=a+b;
		System.out.println(c);
		System.out.println("My name is Durgesh");
	}

}

class Second
{
	public static void main(String args[])
	{
		System.out.println("Second main()");
	}
}

class Third
{

	public static void main(String args[])
	{
		System.out.println("Third main()");
	}

}

class Fourth
{

	public static void main(String args[])
	{
		System.out.println("Fourth main()");
	}

}

class MyFirstProgram
{


}