
public class Helper {
    static void addSomething() {
        System.out.println("I will add something for you");

    }
}
