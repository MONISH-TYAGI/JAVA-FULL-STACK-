class VariableTest
{
	public static void main(String args[])
	{
		System.out.println("This is variable test");
		int x=300;
		int y=60;
		int sum=x+y;
		System.out.println("value of x " + x);

		System.out.println("sum of "+x+" and "+y+" is "+sum);

		double l=330.56;
		String name="dugesh";
		System.out.println(l);
		System.out.println(name);



	}
}

