class LocalExample
{

	public static void m1()
	{
		int temp=50;
	}

	public static void main(String[] args)
	{
		//local variable
		int a=50;
		System.out.println(a);

		if(true)
		{
			int y=55;
			System.out.println(y);
		}
		// System.out.println(y);
		// declare
		int z;
		// initialize
		z=40;
		System.out.println(z);



	}


}