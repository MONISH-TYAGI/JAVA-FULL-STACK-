import java.io.*;
class Input
{
	public static void main(String args[])throws IOException
	{

			// java.util.Scanner  scanner=new java.util.Scanner(System.in);
			// System.out.println("enter number");
			// java.math.BigInteger n=scanner.nextBigInteger();
			// System.out.println("value is "+n.toString());

			// double doubleValue=scanner.nextDouble();
			// System.out.println(doubleValue);


			// nextByte()
			// nextShort()
			// nextInt()
			//nextLong()
			// nextFloat()
			// nextDouble()
			


			// next()--first word
			// nextLine()-- full line

			// System.out.println("Enter welcome message");

			// String welcomeMessage=scanner.nextLine();
			// System.out.println("hello "+welcomeMessage);

			// String word=scanner.next();
			// System.out.println(word.charAt(0));

			// using bufferedReader

		// InputStreamReader streamReader=new InputStreamReader(System.in);
		// BufferedReader	bufferedReader=new BufferedReader(streamReader);

		// String inputString=bufferedReader.readLine();
		// System.out.println(inputString);

		// int n=Integer.parseInt(inputString);
		// Double.parseDouble(string)
		// Float.parseFloat(string)
		// Long.parseLong(string)
		// Boolean.parseBoolean(string)

		// System.out.println(n);
		System.out.println(args[0]);
		System.out.println(args[1]);
		System.out.println(args[2]);
		System.out.println(args[3]);




	}
}