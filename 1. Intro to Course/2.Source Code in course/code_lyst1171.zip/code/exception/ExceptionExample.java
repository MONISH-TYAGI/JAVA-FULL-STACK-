import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ExceptionExample {
    public static void main(String[] args) {

        // System.out.println("starting point");
        // int n1 = 90;
        // int n2 = 0;

        // System.out.println(n1 / n2);
        // System.out.println("this is last statement");

        // BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        // String str = br.readLine();
        // System.out.println(str);

        // System.out.println("ending point");

        // null pointer exception

        // System.out.println("Program started");
        // String str = null;

        // System.out.println(str.length());

        // System.out.println("Program Ternimated");

        // String str = "1234ABC";

        // int intValue = Integer.parseInt(str);

        // System.out.println(str);
        // System.out.println(intValue);

        // System.out.println(34 / 0);
        // int array[] = {
        // 12, 45, 78, 12
        // };

        // System.out.println(array[-1]);

        // String str = "java is serious language";

        // char ch = str.charAt(200);
        // System.out.println(ch);

    }
}
