import java.io.*;

public class GeneratizedExceptionHandling {
    public static void main(String[] args) {

        try {

        } catch (NullPointerException ex) {

        } catch (NumberFormatException ex) {

        } catch (ArrayIndexOutOfBoundsException ex) {

        } catch (IOException ex) {

        } catch (Exception ex) {

        }


        try{


        }catch(Exception ex){
            
        }

        java.util.Map

    }
}
