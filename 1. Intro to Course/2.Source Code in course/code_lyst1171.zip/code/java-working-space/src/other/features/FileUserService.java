package other.features;

public class FileUserService extends  DaoUserService{
}
