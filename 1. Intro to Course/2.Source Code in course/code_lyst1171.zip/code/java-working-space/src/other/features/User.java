package other.features;

//14,15 preview
//16--> permanent
public record User(int userId,String name, String phone)
{

}
