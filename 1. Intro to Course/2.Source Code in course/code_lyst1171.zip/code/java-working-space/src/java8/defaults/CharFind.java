package java8.defaults;

public class CharFind implements  Findable{
    @Override
    public void find() {
        System.out.println("Finding Chars");
    }
}
