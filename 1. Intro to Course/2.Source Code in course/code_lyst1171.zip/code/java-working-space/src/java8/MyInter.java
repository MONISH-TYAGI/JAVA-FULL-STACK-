package java8;

@FunctionalInterface
public interface MyInter {

    void myMethod();

}
