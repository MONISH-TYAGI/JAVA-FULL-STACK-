package java8.ref;

public class CustomPrint {

    public static void printValue(Integer i)
    {
        System.out.println(i);
    }

}
