package java8.ref;

@FunctionalInterface
public interface Findable {
    void find();
}
