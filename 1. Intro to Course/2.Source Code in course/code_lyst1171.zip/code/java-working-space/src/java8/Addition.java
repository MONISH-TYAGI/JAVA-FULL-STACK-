package java8;

public interface Addition {

    void add(int a, int b, int c);

}
