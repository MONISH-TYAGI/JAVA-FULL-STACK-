package generics;

public class Person {
}
