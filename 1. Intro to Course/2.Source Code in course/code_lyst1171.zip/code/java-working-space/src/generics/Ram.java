package generics;

public class Ram extends  Person{
}
