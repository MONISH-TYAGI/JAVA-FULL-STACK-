package inner.classes;

public class Parent {

    public void test1() {
    }

    public void sum() {
    }
}
