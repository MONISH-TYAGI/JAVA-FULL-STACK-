package inner.classes;

public class Interclass {
    interface  InterClassInter{
        void m1();
    }


}
