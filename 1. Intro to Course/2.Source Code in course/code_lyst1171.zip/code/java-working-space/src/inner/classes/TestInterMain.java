package inner.classes;

public class TestInterMain {
    public static void main(String[] args) {



        Interclass.InterClassInter ob= new Interclass.InterClassInter()
        {


            @Override
            public void m1() {

            }
        };
    }
}
