package inner.classes;

public interface OuterInterface {

    interface InnerInterface{

    }


}
