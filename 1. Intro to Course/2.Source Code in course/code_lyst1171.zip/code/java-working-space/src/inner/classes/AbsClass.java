package inner.classes;

public abstract class AbsClass {

    public abstract void m1();

    public void m2() {
        System.out.println("abstract m2()");
    }
}
