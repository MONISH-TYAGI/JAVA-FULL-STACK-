package inner.classes;

public interface Writable {

    void write();
}
