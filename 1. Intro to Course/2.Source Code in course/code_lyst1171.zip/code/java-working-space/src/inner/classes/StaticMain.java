package inner.classes;

public class StaticMain {
    public static void main(String[] args) {


        Outer.Inner inner=new Outer.Inner();
        inner.innerM1();



    }
}
