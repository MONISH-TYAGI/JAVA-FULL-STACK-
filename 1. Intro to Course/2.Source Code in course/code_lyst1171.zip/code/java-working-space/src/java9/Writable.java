package java9;

public interface Writable<U, V, X> {

    void write(U t1, V t2, X x);
}
