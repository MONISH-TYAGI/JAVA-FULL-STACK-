package java9;

public class FindableExample {
    public static void main(String[] args) {

        FileFinder fileFinder = new FileFinder();
        fileFinder.find();
        fileFinder.findDefault();
        fileFinder.doSomeImportantTask();

    }
}
