package java9;

public class FileFinder implements  Findable{

    @Override
    public void find() {
        System.out.println("File is finding");
    }
}
