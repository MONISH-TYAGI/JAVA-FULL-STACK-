public class Test {
    public static void main(String[] args) {
        String str = new String("test");
        System.out.println(str);
    }
}
