public class Test
{
	
	public static void main(String... arg)
	{
		
		System.out.println("Test main()");
		int _abc45$test=45;
		System.out.println(_abc45$test);
		int exports=20;
		int Scanner=30;
		System.out.println(Scanner);
	}

}