class UserDefined
{
	public static void main(String[] args) 
	{
		int n=40;
		Student student1=new Student();	
		student1.name="Durgesh";
		student1.phone=1414L;
		student1.address="DELHI";
		student1.college="ABC College";

		System.out.println(student1.name);
		Student student2=new Student();
		student2.name="Harsh";

		System.out.println(student2.name);




	}
}