import java.util.Scanner;

public class Helper {

    static int inputNumber() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number: ");
        int n = sc.nextInt();
        return n;
    }

}
