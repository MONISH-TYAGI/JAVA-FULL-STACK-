package com.gui.loginwithclock;

public class Main {
    public static void main(String[] args) {
        MainWindow mainWindow = new MainWindow("Login With CLick");
    }
}
