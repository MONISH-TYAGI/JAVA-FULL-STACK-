package com.gui;

import com.gui.components.MyFrame;

public class Demo {
    public static void main(String[] args) {

        System.out.println("Program started");
        MyFrame myFrame=new MyFrame("My Frame");
    }
}
