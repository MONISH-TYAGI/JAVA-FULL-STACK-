package p2; 
 
public class Aloo {
	public Aloo(){
		System.out.println("Creating aloo");
	}

	public void getColor(){
		System.out.println("Aloo color is red");
	}
}