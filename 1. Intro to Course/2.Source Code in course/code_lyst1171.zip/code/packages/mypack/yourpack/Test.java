//this must be first line of your file
package mypack.yourpack;

class Test {
	public static void main(String[] args) {
		System.out.println("this class is in mypack.yourpack");
	}
}
