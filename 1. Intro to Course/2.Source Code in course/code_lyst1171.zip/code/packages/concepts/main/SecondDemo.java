package main;

public class SecondDemo {
    public static void main(String[] args) {
        MainDemo mainDemo = new MainDemo();
        System.out.println(mainDemo.a);
    }
}
