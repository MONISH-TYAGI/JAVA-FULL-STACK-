package lcwd.main.controller;

import main.MainDemo;

public class PageController extends MainDemo {

    public PageController() {
        System.out.println("Creating page controller");
        System.out.println(a);
    }

}
