module com.guest {
    requires com.admin;
}
