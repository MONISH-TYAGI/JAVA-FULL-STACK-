package in.work;

public class WorkService {
}
