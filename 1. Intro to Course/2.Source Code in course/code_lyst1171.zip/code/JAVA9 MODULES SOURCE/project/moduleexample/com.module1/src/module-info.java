module com.module1 {

    requires transitive java.desktop;
    exports com.p1.services;
    exports in.work;
    opens  com.p1.services;





}