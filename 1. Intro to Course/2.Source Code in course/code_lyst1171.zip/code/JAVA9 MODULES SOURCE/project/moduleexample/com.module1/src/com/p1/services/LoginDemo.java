package com.p1.services;

public class LoginDemo {
    public static void main(String[] args) {
        System.out.println("Login module main method");
    }
}
