package com.user.dao;

public class UserDao {

    public void getUsers() {
        System.out.println("Getting users");
    }

    public void saveUser() {
        System.out.println("Saving user");
        System.out.println("user is saved");
    }
}
