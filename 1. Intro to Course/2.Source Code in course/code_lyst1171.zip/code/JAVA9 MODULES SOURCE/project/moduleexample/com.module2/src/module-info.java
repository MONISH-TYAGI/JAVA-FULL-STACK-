module com.module2
{
    requires com.module1;
    exports com.user.dao;
}