module com.module3 {
    requires  com.module1;
    requires com.module2;

}