package com;

import javax.swing.*;

public class GUIMain {
    public static void main(String[] args) {

        JOptionPane.showMessageDialog(null,"this is testing message");

    }
}
