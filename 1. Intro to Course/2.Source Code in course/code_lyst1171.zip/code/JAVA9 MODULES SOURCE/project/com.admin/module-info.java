module com.admin {

    requires java.sql;

    exports com.admin.users;
}