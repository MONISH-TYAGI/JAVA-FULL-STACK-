class DoWhileExample
{
	public static void main(String[] args) {
		 
		 int startPoint=101;
		 do
		 {
		 	System.out.print(startPoint+" ");
		 	startPoint++;
		 }
		 while(startPoint<=150);
		 System.out.println();

	}
}