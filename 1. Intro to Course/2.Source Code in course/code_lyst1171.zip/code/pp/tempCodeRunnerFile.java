 System.out.println("Result : ");
        // printing resultant martix
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                System.out.print(result[i][j] + "\t");
            }
            System.out.println();
        }