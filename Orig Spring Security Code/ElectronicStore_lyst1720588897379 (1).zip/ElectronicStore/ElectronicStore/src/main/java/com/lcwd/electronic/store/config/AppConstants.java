package com.lcwd.electronic.store.config;

public class AppConstants {
    public static final String ROLE_ADMIN = "ADMIN";
    public static final String ROLE_NORMAL = "NORMAL";
    public static final String JWT_HEADER_NAME = "Authorization";
}
