package com.lcwd.electronic.store.entities;

public enum Providers {

    GOOGLE, FACEBOOK, GITHUB, SELF
}
