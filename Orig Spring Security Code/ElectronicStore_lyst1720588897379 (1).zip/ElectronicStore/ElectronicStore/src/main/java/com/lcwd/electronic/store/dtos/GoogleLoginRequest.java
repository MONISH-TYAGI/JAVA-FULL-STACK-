package com.lcwd.electronic.store.dtos;

import lombok.Data;

@Data
public class GoogleLoginRequest {

    private String idToken;
}
