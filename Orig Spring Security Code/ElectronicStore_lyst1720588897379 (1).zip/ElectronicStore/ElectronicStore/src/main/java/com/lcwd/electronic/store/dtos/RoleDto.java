package com.lcwd.electronic.store.dtos;

import lombok.Data;

@Data
public class RoleDto {

    private String roleId;
    private String name;
}
